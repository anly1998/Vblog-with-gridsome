export default {
  "trailingSlash": true,
  "pathPrefix": "",
  "titleTemplate": "%s - Vblog",
  "siteUrl": "",
  "version": "0.7.23",
  "catchLinks": true
}