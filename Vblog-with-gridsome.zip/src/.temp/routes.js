const c1 = () => import(/* webpackChunkName: "page--src-templates-project-details-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\templates\\ProjectDetails.vue")
const c2 = () => import(/* webpackChunkName: "page--src-pages-blog-edit-index-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\pages\\blog\\edit\\index.vue")
const c3 = () => import(/* webpackChunkName: "page--src-templates-blog-details-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\templates\\BlogDetails.vue")
const c4 = () => import(/* webpackChunkName: "page--src-pages-blog-add-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\pages\\blog\\Add.vue")
const c5 = () => import(/* webpackChunkName: "page--src-pages-social-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\pages\\Social.vue")
const c6 = () => import(/* webpackChunkName: "page--src-templates-user-details-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\templates\\UserDetails.vue")
const c7 = () => import(/* webpackChunkName: "page--src-pages-readme-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\pages\\Readme.vue")
const c8 = () => import(/* webpackChunkName: "page--src-pages-project-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\pages\\Project.vue")
const c9 = () => import(/* webpackChunkName: "page--src-pages-helper-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\pages\\Helper.vue")
const c10 = () => import(/* webpackChunkName: "page--src-pages-configure-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\pages\\Configure.vue")
const c11 = () => import(/* webpackChunkName: "page--src-pages-blog-index-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\pages\\blog\\index.vue")
const c12 = () => import(/* webpackChunkName: "page--src-pages-about-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\pages\\About.vue")
const c13 = () => import(/* webpackChunkName: "page--node-modules-gridsome-0-7-23-gridsome-app-pages-404-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\node_modules\\_gridsome@0.7.23@gridsome\\app\\pages\\404.vue")
const c14 = () => import(/* webpackChunkName: "page--src-pages-index-vue" */ "D:\\VSCode\\VSCode-Project\\lagou\\fed-e-task-03-04\\Vblog-with-gridsome\\src\\pages\\Index.vue")

export default [
  {
    path: "/project/details/:name/",
    component: c1
  },
  {
    name: "__blog_edit_id",
    path: "/blog/edit/:id",
    component: c2,
    meta: {
      dataPath: "/blog/edit/_id.json",
      dynamic: true
    }
  },
  {
    path: "/blog/details/:id/",
    component: c3
  },
  {
    path: "/blog/add/",
    component: c4
  },
  {
    path: "/social/:page(\\d+)?/",
    component: c5
  },
  {
    path: "/follower/:login/",
    component: c6
  },
  {
    path: "/following/:login/",
    component: c6
  },
  {
    path: "/readme/",
    component: c7
  },
  {
    path: "/project/",
    component: c8
  },
  {
    path: "/helper/",
    component: c9
  },
  {
    path: "/blog-edit/",
    component: c2
  },
  {
    path: "/configure/",
    component: c10
  },
  {
    path: "/blog/",
    component: c11
  },
  {
    path: "/about/",
    component: c12
  },
  {
    name: "404",
    path: "/404/",
    component: c13
  },
  {
    name: "home",
    path: "/:page(\\d+)?/",
    component: c14
  },
  {
    name: "*",
    path: "*",
    component: c13
  }
]
