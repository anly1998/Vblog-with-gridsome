<template>
  <Layout>
    <div style="min-height: 600px">
      <el-card shadow="never">
        <div
          style="
            min-height: 400px;
            margin-bottom: 20px;
            padding: 20px 0px 20px 0px;
            text-align: center;
          "
        >
          <font style="font-size: 30px; color: #dddddd">
            <b>项目暂未有配置选项，敬请期待！</b>
          </font>
        </div>
      </el-card>
    </div>
  </Layout>
</template>
<script>
export default {
  data() {
    return {
      text: "",
    };
  },
  mounted() {
  },
};
</script>

<style>
</style>
